<?php

namespace Box\Spout\Common\Exception;

/**
 * Class IOException
 *
 * @api
 * @package Box\Spout\Common\Exception
 */
class IOException extends SpoutException
{
}
