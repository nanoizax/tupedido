<div class="container" style="margin-top: 8%; margin-left: 15%">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">

            <h1>Registrar nuevos producto.</h1>

        	<?php
        		
        		echo form_open("usuario/insertProducto");
        		
        		echo form_input_text('nombre', 'Ingresa nombre');

                echo form_input_text('descripcion', 'Ingrese Descripcion');

                echo form_input_text('precio', 'Ingrese Precio');
                
                echo form_input_text('cantidad', 'Ingrese cantidad');
        	
                echo form_submit('Guardar producto');

        		echo form_close();
        	?>
          
        </div>
      </div>
    </div>

    <hr>